create definer = root@localhost view country_view as
select `co`.`Name` AS `co_name`, `ci`.`Name` AS `ci_name`
from (`world`.`country` `co` join `world`.`city` `ci` on ((`co`.`Code` = `ci`.`CountryCode`)));

